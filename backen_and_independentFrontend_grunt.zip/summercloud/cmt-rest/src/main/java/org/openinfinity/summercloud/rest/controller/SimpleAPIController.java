package org.openinfinity.summercloud.rest.controller;

import org.openinfinity.summercloud.entity.TestObject;
import org.openinfinity.summercloud.service.interfaces.TestObjectService;
import org.openinfinity.summercloud.service.interfaces.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

/**
 *
 * @author kavan
 */
@Controller
@RequestMapping("/api")
public class SimpleAPIController {
    
    private final Logger logger = Logger.getLogger(getClass().getName());
    private TestService testService;
    private TestObjectService testObjectService;

    @Autowired
    public SimpleAPIController(TestService testService, TestObjectService testObjectService) {
        this.testService = testService;
        this.testObjectService = testObjectService;
    }
    
    

    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public @ResponseBody
    List<String> listColors(HttpServletResponse response) {
        logger.info("asking colors from service...");
        List<String> colors = testService.listAvalaibleColors();
        return colors;
    }
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public @ResponseBody
    List<TestObject> addObjects(HttpServletResponse response) {
        logger.info("adding 10 TestObject to repository");
        List<TestObject> objs = new LinkedList<>();
        for(int i = 0; i < 10; i++){
            TestObject to = new TestObject();
            to.setId(UUID.randomUUID()+"");
            to.setName("example object" + i);
            to.setValue("time stamp: " + new Date().getTime());
            testObjectService.save(to);
        }
        objs = testObjectService.findAll();
        return objs;
    }

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public @ResponseBody String listtest(HttpServletResponse response) {
        return testObjectService.listNames();
    }



}
