/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.openinfinity.summercloud.repository;

import org.openinfinity.summercloud.repository.interfaces.TestObjectRepositoryCustom;
import org.springframework.stereotype.Component;

/**
 *
 * @author SOLEJKAV
 */
@Component
public class TestObjectRepositoryImpl implements TestObjectRepositoryCustom {

    @Override
    public String listNames() {
        return "something";
    }
    
}
