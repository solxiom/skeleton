/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.openinfinity.summercloud.repository.interfaces;

import org.openinfinity.summercloud.entity.TestObject;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 *
 * @author SOLEJKAV
 */
public interface TestObjectRepository extends MongoRepository<TestObject,String>, TestObjectRepositoryCustom {
    
}
