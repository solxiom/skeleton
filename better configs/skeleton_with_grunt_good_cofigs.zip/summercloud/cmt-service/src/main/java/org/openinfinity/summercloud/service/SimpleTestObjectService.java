/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.openinfinity.summercloud.service;

import org.openinfinity.summercloud.entity.TestObject;
import org.openinfinity.summercloud.repository.interfaces.TestObjectRepository;
import org.openinfinity.summercloud.service.interfaces.TestObjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 * @author SOLEJKAV
 */
@Service
public class SimpleTestObjectService implements TestObjectService {

    
    private TestObjectRepository repo;
    
    @Autowired
    public SimpleTestObjectService(TestObjectRepository repo) {
        this.repo = repo;
    }
    
    
    @Override
    public String listNames() {
        return repo.listNames();
    }

    @Override
    public void save(TestObject obj) {
        repo.save(obj);
    }

    @Override
    public List<TestObject> findAll() {
        return repo.findAll();
    }
    
    
}
